package uk.ac.standrews.cs5001.lec.impl;

import java.util.ArrayList;
import java.util.List;
import uk.ac.standrews.cs5001.lec.interfaces.IFlying;

/**
 * Class representing a list of all the flying things in a particular airspace
 * @author CS5001 Lecturers (c25001.lec@st-andrews.ac.uk)
 */
public class AirspaceTracker {

	private List<IFlying> fliers = new ArrayList<IFlying>();
	
	/**
	 * @param flier the flying object to add
	 */
	public void add(IFlying flier){
		fliers.add(flier);
	}	
	
	public void printFliers(){
		int i = 1;
		for (IFlying f: fliers){
			System.out.println("Flier "+ i + ": "+ f.toString() + " is " + ((f.isInFlight())?"":"not ") + "flying");
			/*System.out.print("Flier "+ i + ": "+ f.toString() + ". ");
			f.printInFlight();*/
			i++;
		}		
	}
}
