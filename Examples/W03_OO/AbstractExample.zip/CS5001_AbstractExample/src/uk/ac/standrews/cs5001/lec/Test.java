package uk.ac.standrews.cs5001.lec;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import uk.ac.standrews.cs5001.lec.impl.*;

/**
 * @author CS5001 Lecturers (c25001.lec@st-andrews.ac.uk)
 */
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Bird jon = new Sparrow("Jon", 1, 32);
		Bird angus = new Penguin("Angus", 2, 5000);
		Sparrow andy = new Sparrow("Andy", 2, 29);
		Penguin devan = new Penguin("Devan", 4, 5101);

		Car pop = new Car("Fiat 500 pop", 115, "B", 'A');
		Aeroplane airbus = new Aeroplane("Airbus", 75000, "CPL");
		Aeroplane cessna = new Aeroplane("Cessna", 175, "LAPL");
		
		// List of Birds
		List<Bird> birds = new ArrayList<>();
		
		birds.add(jon);
		birds.add(angus);
		birds.add(andy);
		birds.add(devan);
		
		System.out.println(birds.toString());

		// List of Vehicles
		List<Vehicle> vehicles = new ArrayList<>();
		vehicles.add(pop);
		vehicles.add(airbus);
		vehicles.add(cessna);

		System.out.println(vehicles.toString());
		
		// Hashtable example with Bird objects 
		Hashtable<String, Bird> table = new Hashtable<String, Bird>(); 
		
		table.put("S2432", jon);
		table.put("D34352", angus);
		table.put("J32534", andy);
				
		System.out.println(table.contains(jon));
		System.out.println(table.contains(devan));

		System.out.println(table.get("S2432"));
		

		//make the fliers fly or land
		andy.fly();
		andy.land();
		airbus.fly();
		airbus.fly();
		cessna.fly();
		
		// Airspace tracker example
		// This accepts anything flying as a member
		
		AirspaceTracker tracker = new AirspaceTracker();
		tracker.add(andy);
		tracker.add(airbus);
		tracker.add(cessna);

		tracker.printFliers();
	
	}

}
