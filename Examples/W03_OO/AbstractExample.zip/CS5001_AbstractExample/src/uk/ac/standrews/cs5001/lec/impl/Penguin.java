package uk.ac.standrews.cs5001.lec.impl;

public class Penguin extends Bird{

	public Penguin(String name, int age, double weight) {
		super(name, age, weight);
	}

	@Override
	public String sing() {
		return "Honk Honk";
	}

}
