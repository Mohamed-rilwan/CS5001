package uk.ac.standrews.cs5001.lec.impl;

import uk.ac.standrews.cs5001.lec.interfaces.IFlying;

public class Aeroplane extends Vehicle implements IFlying{
	private int altitude;
	
	public Aeroplane(String model, int horse_power, String licence_type) {
		super(model, horse_power, licence_type);
		altitude = 0;
	}

	@Override
	public void fly() {
		if ( altitude < 50000 ) {
			altitude += 10000;
		}
	}

	@Override
	public void land() {
		altitude = 0;
	} 
	
	@Override
	public boolean isInFlight() {
		return (altitude > 0);
	}	
}
