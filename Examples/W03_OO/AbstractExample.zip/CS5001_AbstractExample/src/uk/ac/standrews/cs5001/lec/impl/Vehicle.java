package uk.ac.standrews.cs5001.lec.impl;

public abstract class Vehicle {
	private String model;
	private int horsePower;
	private String licenceType;
	
	public Vehicle (String model, int horse_power, String licence_type){
		this.model = model;
		horsePower = horse_power;
		licenceType = licence_type;
	}

	public String getModel() {
		return model;
	}

	protected void setModel(String model) {
		this.model = model;
	}

	public int getEngineCapacity() {
		return horsePower;
	}

	protected void setEngineCapacity(int horse_power) {
		this.horsePower = horse_power;
	}

	public String getLicenceType() {
		return licenceType;
	}

	protected void setLicenceType(String licenceType) {
		this.licenceType = licenceType;
	}
	
	@Override
	public String toString(){
		return model + " (" + licenceType +")"; 
	}
	
}
