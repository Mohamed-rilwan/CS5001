package uk.ac.standrews.cs5001.lec.impl;

/**
 * Abstract base class for bird-like objects. 
 * As this is an abstract class you cannot create an instance of this class directly, 
 * you can only create instances of concrete (non-abstract) classes which extend this class.
 * This abstract base class provides a constructor, a .toString method to return a useful 
 * string representation of a bird-like object and some other get and set utility 
 * methods to access the private fields in subclasses.
 * @author CS5001 Lecturers (c25001.lec@st-andrews.ac.uk)
 *
 */
public abstract class Bird {

	// private fields
	private String name;
	private int age;
	private double weight;
	// custom constructor
	
	/**
	 * @param name the name of the bird object
	 * @param age the age of the bird object 
	 * @param weight the weight of the bird object
	 */
	public Bird (String name, int age, double weight){
		// initialize all the non-static fields
		this.name = name;
		this.age = age;
		this.weight = weight;
	}

	/** 
	 * Change the weight of a bird to the specified value. 
	 * @param weight the new weight of the bird
	 */
	public void setWeight(double weight){
		this.weight = weight;
	}

	/** 
	 * Abstract method to make the bird object sing, this method must be implemented by every concrete subclass.
	 */
	public abstract String sing();

	
	// Useful public methods that override methods in the Object class
	
	
	/**
	 * A method to return a sensible string for all bird-like objects
	 * @return the string representation of this bird-like object
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString(){
		return name + " " + age + " years old weighs " + weight + "g";
	}
	
	
	// Utility methods to access private Bird fields in subclasses of Bird 
	
	/**
	 * @return the age of this person 
	 */
	protected int getAge() {
		return age;
	}

	/**
	 * @param age the age to set
	 */
	public void setAge(int age){
		this.age = age;
	}
	
	/**
	 * @return the name of the Bird object
	 */
	protected String getName(){
		return name;
	}
	

}
