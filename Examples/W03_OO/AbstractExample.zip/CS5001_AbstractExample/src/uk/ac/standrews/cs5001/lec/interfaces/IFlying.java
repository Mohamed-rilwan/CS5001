package uk.ac.standrews.cs5001.lec.interfaces;
/**
 * Interface for objects that can fly
 * @author CS5001 Lecturers (c25001.lec@st-andrews.ac.uk)
 *
 */
public interface IFlying {

	/**
	 * A constant representing standard gravity
	 */
	static final double GRAVITY = 1.0;
	
	void fly();
	void land(); 
	boolean isInFlight();
	
	//adding a new method signature would break any existing code that implements the interface
	//so to avoid this provide a default implementation
	/*
	default void printInFlight() {
		System.out.println(getClass().getSimpleName() + " currently is " + ((isInFlight())?"":"not ") + "in flight");
	}
	*/
}
