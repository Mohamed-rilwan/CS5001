package uk.ac.standrews.cs5001.lec.impl;

import uk.ac.standrews.cs5001.lec.interfaces.IFlying;

public class Sparrow extends Bird implements IFlying {
	private boolean inFlight;
	
	public Sparrow(String name, int age, double weight){
		super(name,age,weight);
		inFlight = false;
	}
	
	// the contractual methods which must be implemented by all bird-like objects
	@Override
	public String sing() {
		return "Chirp Chirp";
	};

	// Useful public methods that override methods in the Object class
	/**
	 * A method to return a sensible string for all sparrow-like objects
	 * @return the string representation of this sparrow-like object
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString(){
		return this.getClass().getSimpleName() + " " + super.toString() + " " + sing();
	}

	@Override
	public void fly() {
		inFlight = true;
	}

	@Override
	public void land() {
		inFlight = false;
	}

	@Override
	public boolean isInFlight() {
		return inFlight;
	}
	
}
