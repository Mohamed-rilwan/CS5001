package uk.ac.standrews.cs5001.lec.impl;

public class Car extends Vehicle {
	private char roadTaxBand;
	
	public Car(String model, int horse_power, String licence_type, char road_tax_band) {
		super(model, horse_power, licence_type);
		roadTaxBand = road_tax_band;
	}

	public char getRoadTaxBand() {
		return roadTaxBand;
	}

	public void setRoadTaxBand(char roadTaxBand) {
		this.roadTaxBand = roadTaxBand;
	}

}
