package uk.ac.standrews.cs.cs5001.tutor.tests;

import uk.ac.standrews.cs.cs5001.tutor.Person;

import org.junit.*;
import static org.junit.Assert.*;


/**
 * Class to test the Person class using the JUnit framework
 * Select "Run as JUnit Test" from menu to launch
 * 
 * @author cs5001 tutor
 */
public class PersonTest{

	private static final String NAME = "Jeff";
	private static final int AGE = 23;

	private Person testPerson;

	
	@BeforeClass // executed once before all other tests in this class
	public static void printInitial() {
		System.out.println("Starting tests on Person class ...");
	}

	
	@Before // executed before each of the other tests in this class
	public void setupTestPerson(){
		System.out.println("setting up new testPerson(" + NAME + ", " + AGE + ")");
		testPerson = new Person(NAME, AGE);    	
	}

	
	@After // executed after each test in this class
	public void printTestPersonDetails() {
		System.out.println("could do something after this test\n");
	}

	
	@AfterClass // executed once after all other tests in this class
	public static void printFinal() {
		System.out.println("... finished tests on Person class");
	}


	@Test public void personConstructorAndGetName() {
		System.out.println("testing constructor and getName");
        assertNotNull(testPerson);
		assertEquals(NAME, testPerson.getName());
	}

	@Test public void personConstructorAndGetAge() {
		System.out.println("testing constructor and getAge");
		assertTrue(testPerson.getAge() == AGE);
	}

	@Test public void setPersonName() {
		System.out.println("testing setName");
		testPerson.setName("Bill");
		assertEquals("Bill", testPerson.getName());
	}

	@Test public void setPersonAge() {
		System.out.println("testing setAge");
		testPerson.setAge(2 * AGE);
		assertEquals(46, testPerson.getAge());        
	}

	@Test public void personEquals(){
		System.out.println("testing .equals method");
		assertEquals(testPerson, new Person(NAME, AGE));
	}
}