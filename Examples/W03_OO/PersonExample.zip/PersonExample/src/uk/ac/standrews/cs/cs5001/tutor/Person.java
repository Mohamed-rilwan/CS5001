package uk.ac.standrews.cs.cs5001.tutor;

/**
 * Sample Person class with custom constructor, accessor methods
 * and .equals overriding .equals inherited from class Object.
 * 
 * @author cs5001 tutor
 */
public class Person {
    private String name;
    private int age;

    // Custom constructor
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // prints out person details
    public void printDetails() {
        System.out.println("\nPerson\n--------\nName: " + name
                   + "\nAge: " + age);  
    }

    // Accessor methods
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    
    // Overriding equals in Object
    @Override
    public boolean equals(Object o){
    	Person p = (Person) o;
    	return(this.name.equals(p.name) && this.age == p.age);
    }
}