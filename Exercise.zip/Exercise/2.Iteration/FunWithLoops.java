public class FunWithLoops {
    public static void main(String[] args) {
        int numberOfRows = Integer.parseInt(args[0]);

        // First and last row
        for (int rows = 0; rows < (numberOfRows / 2); rows++) {

            if (rows == 0 || rows == numberOfRows / 2 - 1) {
                if (rows == 0) {
                    for (int column = 0; column < numberOfRows; column++) {
                        if (column == numberOfRows / 2 - 1) {
                            System.out.print('*');
                        } else {
                            System.out.print(' ');
                        }
                    }
                    System.out.println();
                } else {
                    if (numberOfRows % 2 == 0) {
                        for (int column = 0; column < numberOfRows - 1; column++)
                            System.out.print('*');
                    } else {
                        for (int column = 0; column < numberOfRows - 2; column++)
                            System.out.print('*');
                    }
                }
            } else {
                // Middle rows
                for (int column = 0; column < numberOfRows; column++) {
                    if (column == numberOfRows / 2 - rows - 1 || column == numberOfRows / 2 + rows - 1) {
                        System.out.print('*');
                    } else {
                        System.out.print(' ');
                    }
                }
                System.out.println();
            }
        }
    }
}