import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public record datgramServer() {
    public static void main(String[] args) throws IOException{
        DatagramSocket s = new DatagramSocket(8888);
        byte[] buf = new byte[1500];
        byte[] out = "Hello World".getBytes();

        InetAddress lh = InetAddress.getLocalHost();
        DatagramPacket dpOut = new DatagramPacket(out,out.length,lh,8888);
        DatagramPacket dpIn = new DatagramPacket(buf,buf.length);

        s.send(dpOut);
        s.receive(dpIn);
        
    }
    
}
