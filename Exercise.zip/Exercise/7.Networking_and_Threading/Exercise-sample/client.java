import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class client {

    public static void main(String[] args) throws IOException{
        Socket ss = new Socket("localhost", 8888);

        InputStreamReader isr = new InputStreamReader(ss.getInputStream());
        BufferedReader in = new BufferedReader(isr);
        PrintWriter out = new PrintWriter(ss.getOutputStream(),true);

        out.println("Hello wwodkoijd vniu nsfsonfoi nsoifnsf ");
        String rec = in.readLine();
        System.out.println("read this back from server on client" + rec);
        ss.close(); 

    }
    
}
