public class HWMain{
    public static void main(String[] args){
        HWprinter mainPrinter = new HWprinter();
        mainPrinter.printer();
    }
}