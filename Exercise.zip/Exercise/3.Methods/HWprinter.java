public class HWprinter{
    public void printer(){
        System.out.println("Hello World");
    }
}