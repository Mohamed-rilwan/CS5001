import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileOperation {

    /*
     * This mehtod is used to return the number of line in a file
     * 
     * @param file - takes a file as a input
     * 
     * @return - the total nunber of lines in a file is thrown
     * 
     * @throws FileNotFoundException - returns texcpetion is the input file is not
     * found
     */
    public static int numberOfLineInFile(File file) throws FileNotFoundException {
        int numberOfLines = 0;
        if (file.exists()) {
            Scanner reader = new Scanner(file);
            while (reader.hasNextLine()) {
                numberOfLines += 1;
            }
            reader.close();
            return numberOfLines;
        } else {
            throw new FileNotFoundException("File not found in location");
        }
    }

    /*
     * This mehtod is used to return the number of line in a file
     * @param file - takes a file as a input
     * @return - the total nunber of lines in a file is thrown
     * @throws FileNotFoundException - returns texcpetion is the input file is not
     * found
     */
    public static int lengthOfLine(String lineInFile) {
        if (lineInFile.length() > 0) {
            return lineInFile.length();
        } else {
            return 0;
        }
    }

    /*
     * This mehtod is used to return the number of line in a file along with the line itself
     * @param file - takes a file as a input
     * @return - the total nunber of characters in each line of file
     * @throws FileNotFoundException - returns exception is the input file is not
     * found
     */
    public static void lineAndLength(File file) throws FileNotFoundException {
        if (file.exists()) {
            Scanner reader = new Scanner(file);
            while (reader.hasNextLine()) {
                String data = reader.nextLine();
                System.out.println(lengthOfLine(data) + "  " + data);  
            }
            reader.close();
        } else {
            throw new FileNotFoundException("File not found in location");
        }
    }
}
