import java.io.File;

public class IO {
    public static void main(String[] args) {
        try {

            File directoryPath = new File(args[0]);

            if (!directoryPath.isDirectory()) {
                throw new IllegalArgumentException("The File directory is not valid");
            }

            // List all files in the directory
            if (directoryPath.listFiles().length < 1) {
                System.out.println("No files in the directory");
            } else {
                System.out.println(directoryPath.listFiles());
            }

            //File line and its length
            FileOperation.lineAndLength(directoryPath.listFiles()[0]);
        }

        catch (IndexOutOfBoundsException ex) {
            System.out.println("Invalid arguments");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
}